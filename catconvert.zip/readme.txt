=== Catconvert ===
Contributors: Catconvert
Donate link:
Tags: Youtube, mp3, convert, converter
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 0.1

Adds a download button to youtube movies

== Description ==

Adds a link under embedded video's which allows the users to convert the video to mp3. It supports Youtube, Vimeo, DailyMotion and many others.

Supported Wordpress youtube plugins

Currently these are a number of Youtube Wordpress plugins that we support:
- Default Wordpress behavior without any wordpress plugin
- Smart YouTube PRO
- Viper's Video Quicktags
- YouTube Embed

If you are using a youtube plugin that's not supported please contact us and we will build support for it.

If you have any problems of suggestion please don't hesitate and contact us on info@catconvert.com 

Options include:

- Customize appearance of link with custom css class
- Customize the link text
- Set the position of the link

== Installation ==

1. Upload 'catconvert' folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==


== Screenshots ==
1. Here is how the link is diplayed.
2. The setting page.

== Changelog ==

= 0.1 =
- Initial Revision